from django.apps import AppConfig


class ThreatreportConfig(AppConfig):
    name = 'threatReport'
