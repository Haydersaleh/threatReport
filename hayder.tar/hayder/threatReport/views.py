from django.http import HttpResponse
import hashlib
import datetime
import pytz
#from django.template import loader

from django.shortcuts import render

# Create your views here.
#from django.http import HttpResponse

def index(request):
    return render(request, 'threatReport/index.html')

def addition(request, hay_age):
    return HttpResponse("my age is %s" % hay_age)

def ajax(request):
    tz = pytz.timezone('America/Vancouver')
    #USE_TZ = True
    now = datetime.datetime.now(tz=tz)
    nowFullFormat = now.strftime("%A %Y.%m.%d %I:%M:%S %p")
    nowJSFormat   = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    report = open("/root/depot/report.txt", "r").read()
    hash_object = hashlib.sha1(report.encode('utf-8'))
    sha = hash_object.hexdigest()
    hash = request.GET.get("Hash", "")
    reply = "time = '" + nowFullFormat +"';\ntimeJS = '" + nowJSFormat + "';\n"
    if hash != sha:
        reply += "hash = '" + sha + "';\n <MARKER>" + report + "</MARKER>"
    return HttpResponse( reply )

