/*
	Written by: Hayder Al-Mossawi  - 2019
	This code parses a list of JSON records and render them in a table
*/

hash = '';
time = '';
timeJS = '';
sortingOn='';
periodFilter = '';
order = 1;
var tempfile='';
var file='';

// Entree point of our active code is here
window.onload = function(){ $(document).ready(function() {

	// here we construct the full page
	body = "<div id='mainPage' class='w3-container'>";
	body += "<header id='mainHeader' class='w3-card w3-margin w3-padding-small w3-blue'> This is a sample test program to visualise a threat records file<br>written by Hayder Al-Mossawi 24-01-2019<span class='w3-right' id='time'></span>";
	body += "</header>";
	body += "<div class'w3-bar w3-light-grey'>";
    body += "<div class='w3-card-4 w3-margin w3-padding-small'>";
    body += "<div class='w3-dropdown-hover'><button class='w3-button'>Period Filter</button>\
    					<div class='w3-dropdown-content w3-bar-block w3-card-4'>\
						  <a class='w3-bar-item w3-button filter' filter='1'>Last 24h</a>\
						  <a class='w3-bar-item w3-button filter' filter='7'>Last 7 days</a>\
						  <a class='w3-bar-item w3-button filter' filter='28'>Last 4 weeks</a>\
						  <a class='w3-bar-item w3-button filter' filter='0'>All</a>\
    					</div></div>";
    body += "<button class='w3-btn w3-right w3-red' id='refresh'>Refresh</button>";
    body += "</div>";
    body += "<div class='w3-card w3-margin w3-padding-small' <br><span id='textFilters'></span><span id='report'></span><br>For the demo, you can also drop the records file contents in the field below, it will render the table as it was recieved from the server:<textarea id='reportArea'></textarea></div>";
    body += "</div>";

	$('body').html( body);
	
	heartbeatTimer();
	$('#refresh').hide();

	// sorting 
	$('body').on('click', '.header-btn', function(){
		field = $(this).html();
		if(field == sortingOn)
			order *= -1;
		else{
			sortingOn = field;
			order = 1;
		}
		if(order == -1)
			field = '-'+ field;
		arrayRender( file , field, '', '');
	});
	
	// period filter
	$('body').on('click', '.filter', function(){
		periodFilter = parseInt( $(this).attr('filter') );	
		arrayRender( file, sortingOn, '', '') ;
	})
	
	// text Filters
	$('body').on('keyup', '.textFilter', function(){
		fieldName  = $(this).attr('field') ;
		fieldValue = $(this).val();	
		arrayRender( file, sortingOn, fieldName, fieldValue) ;
	})
	
	// refresh table 
	$('body').on('click', '#refresh', function(){
		file = tempfile;
	    arrayRender( file, sortingOn , '', '') ;
	})
	
	// for the demo, we can also change the file locally on this textarea, and see an immediate.
	$('body').on('change', '#reportArea', function(){
		file = $(this).val();
	    arrayRender( file, sortingOn, '', '' ) ;
	})

	
})}

// periodic pulsing to the server
function heartbeatTimer(){
  sendByAjax( ajaxProcess, 'refreshTimers');
  $('#time').html( time );
  setTimeout( heartbeatTimer, 1000);
}

/* the refresh method consist a send the old hash as an argument, the server checks the file, and recalculate the hash (SHA is used)
   if the old hash == new hash, then no need to send the file again
   if the old hash != new hash, then we send the full file to the client
*/
function sendByAjax(process, Action) {
    $.ajax({ url: 'ajax/', type: 'GET',
          data: {
                action: Action,
	       		Hash: hash,
            }
            })
        .done(function(result) {
			            process(result);
			        })
        .fail(function() {
			        console.log( 'AJAX FAIL ' );
			        })
        .always(function() {
		        });
}

function ajaxProcess(result) {
    var script = document.createElement("script");
	a = result.indexOf("<MARKER>");
    	b = result.indexOf("</MARKER>");
	if(a > -1){
		scr = result.substring(0, a);
		script.innerHTML = scr;
        	if(b > -1){
        		// safe texte converting of the received JSON list
	        	tempfile = result.substring(a+8 , b).replace(/\'/g, '\"').replace(/‘/g, '\"').replace(/’/g, '\"');
	        	if(file ==''){
	        		file = tempfile;
	        		arrayRender( file, '', '', '') ;
	        	} else
	        		$('#refresh').show();			// do not render, but inform the user to refresh
	        }
	}
	else
		script.innerHTML = result;
 document.body.appendChild(script);
 document.body.removeChild(script);
}

// comparing fonction, propert is the name of the field, according to which the sorting will be, if preceded by "-", then the sorting is inverse
function dynamicSort(property) {
    var sortOrder = 1;
    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a,b) {
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
}

// converts the JSON list to an HTML table, the JSON object could be of any number of fields, 
/* Inputs: 
  str : the JSON list string
  sortKey : if '' , then no sorting applied, if = field, then the table is sorted on field, if -field, the table is inversely sorted on field
  fieldName: if = field, then the lines are filtered, only the values that contains fieldValue will show up
*/
function arrayRender( str , sortKey, fieldName, fieldValue){
var count =0;
var bodyString = '';
var date = '';

	recordsArray = JSON.parse( str );
	
	if(recordsArray.length > 0){	
		if ( periodFilter > 0 ){
			date = new Date( timeJS );
			date.setDate( date.getDate() - periodFilter);
		}
			
		// sorting the array		
		if(sortKey)
			recordsArray.sort( dynamicSort( sortKey ) );
			
		bodyString = "<table class='w3-table w3-bordered w3-hoverable'>";
		obj = recordsArray[0];
		headerString = "<tr class='w3-blue tr_headers'><th class='th_counter'></th>";
		
		filterString = "<table class='w3-table'><tr class='tr_headers'><td class='th_counter'>Value Filters:</td>";
		
		// first, lets build the table header
		for( var key in obj){
			sorted = '';
			if(sortKey && sortKey.indexOf(key)> -1)
				sorted = ' sorted';
			headerString += "<th class='th_" + key + "'><button class='w3-btn header-btn header_" + key + sorted + "'>" + key + "</button></th>";
			filterString += "<td class='td_" + key + "'><input class='textFilter' field='" + key + "' placeholder='"+ key +"'/</td>";
			}
			
		headerString += "</tr>";
		filterString += "</tr></table>";
		
		bodyString += headerString;
		
		// here we build the lines of the table
		for(var index in recordsArray){
			record = recordsArray[ index ];
			if(date == '' || (date !='' && (date < new Date(record['date']) ) ) )
			if(fieldName =='' || (fieldName != '' && (record[ fieldName ]).indexOf( fieldValue) > -1 ) ) {
				lineString = "<tr class='line tr_" + (index % 2) + " rating_" + record[ 'rating' ] + "'><td class='td_counter'><span class='val_counter'>" + ++count + "</span></td>";
				for( var key in record)
					lineString += "<td class='td_" + key + "'><span class='val_" + key + "'>" + record[ key ] + "</span></td>";
				bodyString += lineString + "</tr>";
			}
		}
		bodyString += "</table>";
	}
// save a copy of the JSON list in a textarea for the slake of demo
$('#reportArea').val( str );
	
// render the table
$('#report').html( bodyString );

// write the text filter table only once
if($('#textFilters').html() =='')
	$('#textFilters').html( filterString );
}
